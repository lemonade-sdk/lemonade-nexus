# Independent verification of this collection

Performed off-host against the archived bytes.

1. AMD certificate chain
   VCEK <- ASK (CN=SEV-Genoa) <- ARK (CN=ARK-Genoa, self-signed)
   openssl verify: OK

2. SEV-SNP report signature
   Signed region: report bytes 0x000-0x2A0 (672 bytes)
   Algorithm: ECDSA P-384 over SHA-384, r and s stored little-endian
   Verified under the VCEK public key: "Verified OK"

3. Challenge binding
   evidence/challenge.bin = 9d5d8d12d48b8abd98775e3cefed2ab7f888ca4dbf7c40333f513b0af0f4e9bb
   REPORT_DATA == SHA-512(challenge): true
   The reference run carries a different REPORT_DATA and the same
   MEASUREMENT, which is what a fresh challenge over a stable image gives.

The SEV-SNP evidence on this host is genuine and hardware-rooted.
The vTPM evidence is not: see platform/vtpm-boundary.txt.
