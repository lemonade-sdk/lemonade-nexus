Lemonade Nexus attestation evidence
===================================

Collector version: 0.1.0
Mode:              reference
Started UTC:       2026-08-26T01:13:12Z
Nexus binary:      /usr/local/bin/nexus
Nexus service:     nexus.service
PCR selection:     sha256:0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23

This directory contains collected evidence only.

The collector does not decide whether this host is Tier 1 eligible.
A remote Nexus verifier must:

1. Examine the Azure SEV-SNP report and endorsement chain.
2. Bind the vTPM attestation key to the SEV-SNP report.
3. Verify the TPM quote with the caller challenge.
4. Replay the measured-boot event log.
5. Replay the IMA log and compare it with quoted PCR 10.
6. Compare boot, runtime, binary, and policy measurements with the approved profile.
7. Check node identity, incarnation, epoch, and Nexus security rules.

Missing evidence appears in status.tsv.
Command errors appear in errors/.
